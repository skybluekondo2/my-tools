-- after login as SYSTEM
DROP MATERIALIZED VIEW all_cust_sales_mv;
DROP MATERIALIZED VIEW costs_mv;
DROP MATERIALIZED VIEW costs_pm_mv;
DROP MATERIALIZED VIEW cust_sales_mv;
DROP MATERIALIZED VIEW some_cust_sales_mv;
DROP MATERIALIZED VIEW cust_id_sales_aggr;
DROP MATERIALIZED VIEW sales_cube_mv;
DROP MATERIALIZED VIEW sales_gby_mv;

DROP MATERIALIZED VIEW CUST_TOTAL_SALES_MV;
DROP MATERIALIZED VIEW CUST_SALES_TIME_MV;


alter system flush shared_pool;

grant advisor to sh;

-- Added 2004.04.08
grant UNLIMITED TABLESPACE to sh;
alter user sh identified by sh;
grant connect, resource, dba to sh;
alter user sh account unlock;


-- connect sh
connect sh/sh;


SELECT c.cust_last_name, sum(s.amount_sold) AS dollars,
sum(s.quantity_sold) as quantity
FROM sales s , customers c, products p
WHERE c.cust_id = s.cust_id
AND s.prod_id = p.prod_id
AND c.cust_state_province IN ('Dublin','Galway')
GROUP BY c.cust_last_name;


SELECT c.cust_id, SUM(amount_sold) AS dollar_sales 
  FROM sales s, customers c WHERE s.cust_id= c.cust_id  GROUP BY c.cust_id;

select sum(unit_cost) from costs group by prod_id;



