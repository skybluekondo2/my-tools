grant connect, resource, dba to HR;
alter user HR account unlock;
alter user HR identified by HR;

conn HR/HR


DROP TABLE EMPLOYEES1;

CREATE TABLE "EMPLOYEES1" ( 
"EMPLOYEE_ID" NUMBER(6), 
"FIRST_NAME" VARCHAR2(20), 
"LAST_NAME" VARCHAR2(25), 
"EMAIL" VARCHAR2(25), 
"PHONE_NUMBER" VARCHAR2(20), 
"HIRE_DATE" DATE, 
"JOB_ID" VARCHAR2(10), 
"SALARY" NUMBER(8, 2), 
"COMMISSION_PCT" NUMBER(2, 2), 
"MANAGER_ID" NUMBER(6), 
"DEPARTMENT_ID" NUMBER(4));

ALTER TABLE "HR"."EMPLOYEES1" ENABLE ROW MOVEMENT;

begin
  for i in 1..1250 loop
     insert into employees1
     select * from hr.employees;
     commit;
  end loop;
end;
/

delete employees1 where department_id = 50;
commit;

begin
  for i in 1..1250 loop
     insert into employees1
     select * from hr.employees;
     commit;
  end loop;
end;
/

delete employees1 where department_id = 30;
commit;
delete employees1 where department_id = 100;
commit;
delete employees1 where department_id = 50;
commit;
delete employees1 where department_id = 80;
commit;
/