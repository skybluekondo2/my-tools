grant connect, resource, dba to sh;
alter user sh identified by sh account unlock;


conn sh/sh

  drop index sales_time_bix;
  create index sales_time_idx on sales(time_id) compute statistics;


  CREATE OR REPLACE PROCEDURE fetch_n_rows(
    stmt  VARCHAR,
    name  VARCHAR,
    nexec NUMBER  := 1,
    nrows NUMBER  := 0,
    debug BOOLEAN := FALSE)
    IS
      -- Local variables
      curs     INTEGER := null;
      rc       INTEGER;
      nexec_it INTEGER := 0;
      nrows_it INTEGER;
    BEGIN

      dbms_application_info.set_module('DEMO', name);

      WHILE (nexec_it < nexec)
      LOOP

        curs := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(curs, stmt, DBMS_SQL.NATIVE);
        rc   := DBMS_SQL.EXECUTE(curs);
        nrows_it := 0;

        LOOP
          IF (dbms_sql.fetch_rows(curs) <= 0 OR (nrows <> 0 AND nrows_it = nrows
))
          THEN
            EXIT;
          ELSE IF (debug = TRUE)
            THEN
              DBMS_OUTPUT.PUT_LINE(nrows_it);
            END IF;
          END IF;

          nrows_it := nrows_it + 1;

        END LOOP;

        DBMS_SQL.CLOSE_CURSOR(curs);

       nexec_it := nexec_it + 1;

     END LOOP;

     dbms_application_info.set_module(null, null);

    END fetch_n_rows;
/

