conn sh/sh

drop index sales_time_idx;

drop procedure fetch_n_rows;

create bitmap index sales_time_bix
on sales(time_id)
local nologging compute statistics;

